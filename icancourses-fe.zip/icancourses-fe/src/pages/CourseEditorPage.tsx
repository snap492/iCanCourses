// === src/pages/CourseEditorPage.tsx ================

import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function CourseEditorPage() {
    const navigate = useNavigate();
    const [course, setCourse] = useState({
        title: '',
        description: '',
        coverUrl: '',
        structure: [],
    });

    return (
        <div className="min-h-screen bg-gray-100 p-6">
            <header className="flex justify-between items-center mb-6">
                <div className="space-x-4">
                    <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-black">Назад</button>
                    <button className="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded">Сохранить</button>
                    <button className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded">Экспортировать в SCORM</button>
                </div>
            </header>
            <div className="bg-white p-6 rounded-2xl shadow-md space-y-6">
                <div>
                    <label className="block font-semibold mb-1">Название курса:</label>
                    <input
                        type="text"
                        className="w-full border rounded p-2"
                        value={course.title}
                        onChange={(e) => setCourse({ ...course, title: e.target.value })}
                    />
                </div>
                <div>
                    <label className="block font-semibold mb-1">Описание курса:</label>
                    <textarea
                        className="w-full border rounded p-2"
                        rows={4}
                        value={course.description}
                        onChange={(e) => setCourse({ ...course, description: e.target.value })}
                    ></textarea>
                </div>
                <div>
                    <label className="block font-semibold mb-1">Обложка курса:</label>
                    <input type="file" className="w-full" />
                </div>
            </div>
            <div className="mt-8">
                <h2 className="text-xl font-bold mb-4">Структура курса</h2>
                <div className="bg-white p-6 rounded-2xl shadow-md space-y-4">
                    <div className="text-gray-400">Пока нет материалов</div>
                    <button className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded">
                        + Добавить материал
                    </button>
                </div>
            </div>
        </div>
    );
}